def generic_hi(name="world"):
    
    """ Says Hi to a specific name """
    return "Hello, " + name + "!"
   


        