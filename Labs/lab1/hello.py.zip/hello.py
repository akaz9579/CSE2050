def say_hi():
    """Program returns hello world""" 
    
    return "Hello, world"
